/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
/**
 *
 * @author laboratorio
 */
class Util{
    public static int hash(int numero, int tamanho){
        return numero % tamanho;
    }
}


public class Exemplo2 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        
        ArrayList<Integer>[] tabela = new ArrayList[10];
        
        for (int i =0; i < tabela.length; i++){
            tabela[i] = new ArrayList<>();
        }
        
        //receber um numero
        int numero, endereco;
        for(int i = 0; i<5; i++){
            System.out.println("Numero: ");
            numero = teclado.nextInt();
     
        //calcuclar o endereço do numero dentro da tabela para o espalhamento
        endereco = numero % tabela.length;
        System.out.println("Endereco gerado: " +endereco);
        
        //Controla duplicados
        if(tabela[endereco].contains(numero)){
            System.out.println("Numero ja existe na tabela");
        }//Inserir o numero no endereço gerado
        else{
            tabela[endereco].add(numero);
            System.out.println("Numero inserido com sucesso");
        }
        }
        
     for(int i = 0; i < tabela.length; i++){
         System.out.println("Posicao " + i + ": " +tabela[i]);
     }           
    }
}
